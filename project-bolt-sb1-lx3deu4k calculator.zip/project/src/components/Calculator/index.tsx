import React from 'react';
import { Calculator as CalculatorIcon } from 'lucide-react';
import useCalculator from './useCalculator';
import BasicInputs from './BasicInputs';
import ResultsSection from './ResultsSection';
import PortfolioSection from './PortfolioSection';
import ExpensesSection from './ExpensesSection';
import LifeEventsSection from './LifeEventsSection';

export default function Calculator() {
  const {
    inputs,
    lifeEvents,
    fireNumber,
    yearsToFI,
    projectionData,
    analysis,
    handlers
  } = useCalculator();

  return (
    <div className="bg-white rounded-lg shadow-lg p-6 max-w-4xl mx-auto">
      <div className="flex items-center gap-2 mb-6">
        <CalculatorIcon className="w-6 h-6 text-blue-600" />
        <h2 className="text-2xl font-bold text-gray-800">FIRE Calculator (INR)</h2>
      </div>

      <div className="space-y-6">
        <BasicInputs inputs={inputs} onChange={handlers.handleInputChange} />
        
        <ResultsSection
          fireNumber={fireNumber}
          yearsToFI={yearsToFI}
          currentExpenses={inputs.annualExpenses}
          retirementExpenses={inputs.annualExpenses * Math.pow(1 + (inputs.inflationRate + inputs.expenseGrowthRate) / 100, yearsToFI)}
        />

        <PortfolioSection
          inputs={inputs}
          fireNumber={fireNumber}
          handlers={handlers}
        />

        <ExpensesSection
          inputs={inputs}
          handlers={handlers}
        />

        <LifeEventsSection
          lifeEvents={lifeEvents}
          handlers={handlers}
        />
      </div>
    </div>
  );
}