import { calculateFIRENumber, calculateYearsToFI } from '../calculations';

describe('FIRE Calculations', () => {
  describe('calculateFIRENumber', () => {
    it('should calculate correct FIRE number', () => {
      expect(calculateFIRENumber(40000, 4)).toBe(1000000);
      expect(calculateFIRENumber(60000, 3)).toBe(2000000);
    });
  });

  describe('calculateYearsToFI', () => {
    it('should calculate years to FI correctly', () => {
      // Starting with $100k, contributing $5k monthly, 7% return, target $1M
      const years = calculateYearsToFI(100000, 5000, 7, 1000000);
      expect(years).toBeGreaterThan(0);
      expect(years).toBeLessThan(100);
    });

    it('should handle edge cases', () => {
      // Already reached target
      expect(calculateYearsToFI(1000000, 5000, 7, 1000000)).toBe(0);
      
      // Impossible scenario (no contributions, negative return)
      expect(calculateYearsToFI(0, 0, 0, 1000000)).toBe(100);
    });
  });
});