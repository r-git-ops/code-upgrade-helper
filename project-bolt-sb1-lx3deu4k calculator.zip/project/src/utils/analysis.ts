import { FIREAnalysis } from '../types';

export const analyzeFIREPlan = (
  currentAge: number,
  targetRetirementAge: number,
  currentSavings: number,
  monthlyContribution: number,
  annualIncome: number,
  yearsToFI: number,
  fireNumber: number
): FIREAnalysis => {
  const actualRetirementAge = currentAge + yearsToFI;
  const achievable = actualRetirementAge <= targetRetirementAge;
  const shortfall = achievable ? 0 : fireNumber - (currentSavings + (monthlyContribution * 12 * (targetRetirementAge - currentAge)));
  const savingsRate = (monthlyContribution * 12) / annualIncome * 100;

  const recommendations: string[] = [];

  // Generate personalized recommendations
  if (!achievable) {
    if (savingsRate < 20) {
      recommendations.push("Consider increasing your savings rate to at least 20% of your income");
    }
    if (monthlyContribution < annualIncome / 24) {
      recommendations.push("Try to increase your monthly contributions");
    }
    recommendations.push("Look for ways to increase your income through side hustles or career growth");
  }

  if (currentSavings < annualIncome) {
    recommendations.push("Build an emergency fund of 6-12 months of expenses");
  }

  if (yearsToFI > 25) {
    recommendations.push("Consider optimizing your investment strategy for better returns");
  }

  return {
    achievable,
    actualRetirementAge,
    shortfall,
    savingsRate,
    recommendations
  };
};