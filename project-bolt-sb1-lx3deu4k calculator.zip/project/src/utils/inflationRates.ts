export const defaultCategoryInflationRates = {
  milestone: 6,
  luxury: 6,
  family: 6,
  health: 12,
  education: 10,
} as const;

export type ExpenseCategory = keyof typeof defaultCategoryInflationRates;

export const calculateInflatedCost = (
  baseCost: number,
  category: ExpenseCategory,
  yearsFromNow: number,
  customInflationRate?: number,
  defaultRates = defaultCategoryInflationRates
): number => {
  const inflationRate = customInflationRate ?? defaultRates[category];
  return Math.round(baseCost * Math.pow(1 + inflationRate / 100, yearsFromNow));
};