export interface LifeEvent {
  age: number;
  name: string;
  cost: number;
  description: string;
  category: 'milestone' | 'luxury' | 'family' | 'health' | 'education';
  priority: 'essential' | 'important' | 'optional';
  inflationRate?: number; // Custom inflation rate per event
}

export interface LifeEventsState {
  events: LifeEvent[];
  enabled: boolean;
  defaultInflationRates: {
    milestone: number;
    luxury: number;
    family: number;
    health: number;
    education: number;
  };
}