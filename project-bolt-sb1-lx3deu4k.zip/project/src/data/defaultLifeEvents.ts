import { LifeEvent } from '../types/lifeEvents';

export const defaultLifeEvents: LifeEvent[] = [
  {
    age: 34,
    name: "Wedding",
    cost: 2500000, // ₹25L
    description: "Traditional Indian wedding expenses including venue, catering, and ceremonies",
    category: "milestone",
    priority: "important"
  },
  {
    age: 35,
    name: "First Child Education Fund",
    cost: 1000000, // ₹10L initial fund
    description: "Initial education fund setup for first child",
    category: "education",
    priority: "essential"
  },
  {
    age: 40,
    name: "Luxury Car",
    cost: 4000000, // ₹40L
    description: "Upgrade to a luxury vehicle",
    category: "luxury",
    priority: "optional"
  },
  {
    age: 45,
    name: "Property Investment",
    cost: 10000000, // ₹1Cr
    description: "Investment in a second property",
    category: "milestone",
    priority: "important"
  },
  {
    age: 50,
    name: "Children's Higher Education",
    cost: 5000000, // ₹50L
    description: "College/University fund for children",
    category: "education",
    priority: "essential"
  },
  {
    age: 55,
    name: "Health Fund",
    cost: 2000000, // ₹20L
    description: "Emergency health and medical fund",
    category: "health",
    priority: "essential"
  }
];