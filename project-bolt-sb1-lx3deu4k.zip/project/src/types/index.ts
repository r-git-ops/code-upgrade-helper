import type { MonthlyExpenses, IncomeDetails, InvestmentAllocation } from './calculations';

export interface FIRECalculation {
  currentAge: number;
  retirementAge: number;
  currentSavings: number;
  monthlyContribution: number;
  expectedReturn: number;
  annualExpenses: number;
  withdrawalRate: number;
  inflationRate: number;
  salaryGrowthRate?: number;
  expenseGrowthRate?: number;
  monthlyExpenses?: MonthlyExpenses;
  incomeDetails?: IncomeDetails;
  investmentAllocation?: InvestmentAllocation;
}

export interface ProjectionDataPoint {
  age: number;
  balance: number;
  fireTarget: number;
  annualExpenses: number;
  yearlyContribution: number;
  yearlyReturns: number;
  totalRequired: number;
  isRetired: boolean;
  hasReachedFIRE: boolean;
  isTargetRetirementAge: boolean;
  isActualRetirementAge: boolean;
}

export interface FIREAnalysis {
  achievable: boolean;
  actualRetirementAge: number;
  shortfall: number;
  savingsRate: number;
  recommendations: string[];
  monthlyInvestmentNeeded?: number;
  yearsToFI: number;
}

export type { MonthlyExpenses, IncomeDetails, InvestmentAllocation };