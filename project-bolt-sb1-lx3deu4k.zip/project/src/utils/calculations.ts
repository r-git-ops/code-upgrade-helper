import { calculateInflatedCost } from './inflationRates';
import type { ProjectionDataPoint, FIRECalculation } from '../types';
import type { LifeEvent } from '../types/lifeEvents';

const LIFE_EXPECTANCY = 85;

export const calculateFIRENumber = (
  annualExpenses: number,
  withdrawalRate: number,
  currentAge: number = 0,
  retirementAge: number = 0,
  inflationRate: number = 6,
  expenseGrowthRate: number = 2
): number => {
  const years = retirementAge - currentAge;
  const totalGrowthRate = (1 + inflationRate / 100) * (1 + expenseGrowthRate / 100) - 1;
  const futureExpenses = annualExpenses * Math.pow(1 + totalGrowthRate, years);
  return Math.round((futureExpenses * 100) / withdrawalRate);
};

export const calculateYearsToFI = (
  currentSavings: number,
  monthlyContribution: number,
  annualReturn: number,
  targetAmount: number,
  inflationRate: number = 6,
  salaryGrowthRate: number = 5
): number => {
  if (currentSavings >= targetAmount) return 0;
  if (monthlyContribution <= 0 && currentSavings < targetAmount) return 100;

  const realReturn = (1 + annualReturn / 100) / (1 + inflationRate / 100) - 1;
  let balance = currentSavings;
  let years = 0;
  let contribution = monthlyContribution * 12;

  while (balance < targetAmount && years < 100) {
    balance = balance * (1 + realReturn) + contribution;
    contribution *= (1 + salaryGrowthRate / 100);
    years++;
  }

  return years;
};

export const calculateProjection = (
  currentSavings: number,
  monthlyContribution: number,
  annualReturn: number,
  fireNumber: number,
  currentAge: number,
  retirementAge: number,
  annualExpenses: number,
  inflationRate: number = 6,
  salaryGrowthRate: number = 5,
  expenseGrowthRate: number = 2
): ProjectionDataPoint[] => {
  let balance = currentSavings;
  const data: ProjectionDataPoint[] = [];
  let currentExpenses = annualExpenses;
  let yearlyContribution = monthlyContribution * 12;
  const returnRate = annualReturn / 100;
  const actualRetirementAge = currentAge + calculateYearsToFI(
    currentSavings,
    monthlyContribution,
    annualReturn,
    fireNumber,
    inflationRate,
    salaryGrowthRate
  );

  for (let age = currentAge; age <= LIFE_EXPECTANCY; age++) {
    const totalExpenseGrowth = (1 + inflationRate / 100) * (1 + expenseGrowthRate / 100) - 1;
    const fireTarget = calculateFIRENumber(
      currentExpenses,
      4,
      currentAge,
      retirementAge,
      inflationRate,
      expenseGrowthRate
    );
    
    const isRetired = age >= retirementAge;
    const hasReachedFIRE = balance >= fireTarget;
    const yearlyReturns = balance * returnRate;
    
    // Calculate next year's balance
    let nextBalance = balance;
    if (!isRetired && !hasReachedFIRE) {
      // During accumulation phase: add returns and contributions
      nextBalance = balance + yearlyReturns + yearlyContribution;
    } else {
      // During retirement: add returns and subtract expenses
      nextBalance = balance + yearlyReturns - currentExpenses;
    }
    
    data.push({
      age,
      balance: Math.round(balance),
      fireTarget,
      annualExpenses: Math.round(currentExpenses),
      yearlyContribution: Math.round(yearlyContribution),
      yearlyReturns: Math.round(yearlyReturns),
      totalRequired: fireTarget,
      isRetired,
      hasReachedFIRE,
      isTargetRetirementAge: age === retirementAge,
      isActualRetirementAge: age === actualRetirementAge
    });
    
    // Update values for next year
    balance = nextBalance;
    if (!isRetired && !hasReachedFIRE) {
      yearlyContribution *= (1 + salaryGrowthRate / 100);
    } else {
      yearlyContribution = 0;
    }
    currentExpenses *= (1 + totalExpenseGrowth);
  }
  
  return data;
};

export const calculateWithLifeEvents = (
  projectionData: ProjectionDataPoint[],
  lifeEvents: LifeEvent[],
  currentAge: number
): ProjectionDataPoint[] => {
  let runningBalance = projectionData[0].balance;
  
  return projectionData.map((point, index) => {
    const eventsAtAge = lifeEvents.filter(event => event.age === point.age);
    const eventsCost = eventsAtAge.reduce((total, event) => {
      const yearsFromNow = event.age - currentAge;
      return total + calculateInflatedCost(event.cost, event.category, yearsFromNow);
    }, 0);
    
    if (eventsCost > 0) {
      runningBalance = Math.max(0, runningBalance - eventsCost);
    }
    
    // Update running balance based on returns, contributions, and expenses
    if (index < projectionData.length - 1) {
      if (!point.isRetired && !point.hasReachedFIRE) {
        runningBalance = runningBalance + point.yearlyReturns + point.yearlyContribution;
      } else {
        runningBalance = runningBalance + point.yearlyReturns - point.annualExpenses;
      }
    }
    
    return {
      ...point,
      balance: Math.round(runningBalance),
      annualExpenses: point.annualExpenses + (eventsCost > 0 ? eventsCost : 0)
    };
  });
};