// Currency formatter for INR
export const formatINR = (amount: number): string => {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  }).format(amount);
};

// Compact currency formatter for charts (1,00,000 -> ₹1L)
export const formatCompactINR = (amount: number): string => {
  if (amount >= 10000000) { // 1 Cr
    return `₹${(amount / 10000000).toFixed(1)}Cr`;
  } else if (amount >= 100000) { // 1 L
    return `₹${(amount / 100000).toFixed(1)}L`;
  }
  return formatINR(amount);
};